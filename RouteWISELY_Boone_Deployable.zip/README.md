# RouteWISELY™ – Boone County, KY Deployment

## 📁 Project Structure

Each RouteWISELY™ project is organized in its own subfolder within `/public`. This prevents cross-contamination, simplifies testing, and allows independent version control.

```
/public
  └── boone/
      ├── index.html
      ├── app.js
      ├── style.css
      └── project.geojson
```

## 🚀 Deployment Instructions

To deploy this project using Firebase:

1. Set the public directory to the target folder:
   ```json
   {
     "hosting": {
       "public": "public/boone",
       "ignore": ["firebase.json", "**/.*", "**/node_modules/**"]
     }
   }
   ```

2. From the root of your Firebase project:
   ```bash
   firebase deploy
   ```

3. Open the hosted map:
   ```
   https://your-project-id.web.app/
   ```

## 📌 Notes

- Only one `project.geojson` file should exist per project folder.
- The file must contain properly formatted GeoJSON with `Point` features.
- Clustering is automatically enabled in `app.js` using:
  ```js
  L.markerClusterGroup({ disableClusteringAtZoom: 17 })
  ```

## 🧠 Best Practices

- Use one folder per municipality (e.g., `/boone`, `/madison`, `/grafton`)
- Always use the filename `project.geojson` for consistency
- Do not deploy developer notes (like README.md) to Firebase hosting

---

Generated for internal deployment and tracking. For assistance, contact the RouteWISELY™ DevOps team.
