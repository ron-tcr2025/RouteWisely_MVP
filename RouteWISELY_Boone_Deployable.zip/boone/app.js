
const mapName = 'project.geojson'; // No query param needed
const THRESHOLD_METERS = 8;
const STORAGE_KEY = 'visitedMarkers';
const ID_FIELD = 'index';

document.addEventListener('DOMContentLoaded', () => {
  let map = L.map('map').setView([0, 0], 17);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '© OpenStreetMap contributors'
  }).addTo(map);

  let useClustering = true;
  let markerGroup = useClustering
    ? L.markerClusterGroup({ disableClusteringAtZoom: 17 })
    : L.layerGroup();
  map.addLayer(markerGroup);

  let geoLayer, userMarker, userHeading = null, arrowLine = null;
  const visited = loadVisited();

  document.getElementById('locBtn').onclick = () => {
    if (userMarker) map.setView(userMarker.getLatLng(), 17);
  };

  const logPanel = document.createElement("div");
  logPanel.id = "logPanel";
  logPanel.style.cssText = "position:absolute;bottom:1rem;left:1rem;z-index:1000;background:#fff;padding:8px 12px;border-radius:6px;box-shadow:0 1px 4px rgba(0,0,0,0.3);font-size:0.9rem;";
  document.body.appendChild(logPanel);

  let startTime = new Date();
  function updateLogPanel() {
    const now = new Date();
    const elapsed = new Date(now - startTime).toISOString().substr(11, 8);
    logPanel.innerHTML = `
      <b>Driver Log</b><br/>
      Start: ${startTime.toLocaleTimeString()}<br/>
      Now: ${now.toLocaleTimeString()}<br/>
      Elapsed: ${elapsed}
    `;
  }
  setInterval(updateLogPanel, 10000);
  updateLogPanel();

  fetch(mapName)
    .then(res => res.json())
    .then(data => {
      geoLayer = L.geoJSON(data, {
        pointToLayer: (feature, latlng) => {
          return L.circleMarker(latlng, markerStyle(visited.has(getId(feature))));
        }
      });

      geoLayer.eachLayer(l => markerGroup.addLayer(l));
      map.fitBounds(geoLayer.getBounds());
      startTracking();
    })
    .catch(console.error);

  function startTracking() {
    navigator.geolocation.watchPosition(updatePosition, showError, {
      enableHighAccuracy: true,
      maximumAge: 500,
      timeout: 10000
    });
  }

  function updatePosition({ coords }) {
    const latlng = [coords.latitude, coords.longitude];
    const heading = coords.heading;

    if (userMarker) {
      userMarker.setLatLng(latlng);
    } else {
      userMarker = L.circleMarker(latlng, {
        radius: 6, color: '#0066ff', fillColor: '#0066ff', fillOpacity: 0.9
      }).addTo(map);
    }

    if (heading !== null && !isNaN(heading)) {
      userHeading = heading;
      userMarker.setRotationAngle(heading);
    }

    map.setView(latlng, 17);

    let nextPoint = null, nextDist = Infinity;

    geoLayer.eachLayer(layer => {
      const id = getId(layer.feature);
      const dist = haversine(latlng, layer.getLatLng());

      if (!visited.has(id) && dist < THRESHOLD_METERS) {
        visited.add(id);
        layer.setStyle(markerStyle(true));
        saveVisited();
      }

      if (!visited.has(id) && dist < nextDist) {
        nextDist = dist;
        nextPoint = layer.getLatLng();
      }
    });

    updateArrow(latlng, nextPoint);
  }

  function updateArrow(from, to) {
    if (arrowLine) map.removeLayer(arrowLine);
    if (from && to) {
      arrowLine = L.polyline([from, to], {
        color: '#0074d9',
        weight: 3,
        dashArray: '4,6'
      }).addTo(map);
    }
  }

  function showError(err) {
    console.warn('Geolocation error:', err);
  }

  function getId(feature) {
    return feature.properties?.[ID_FIELD]?.toString()
      || feature.id?.toString()
      || JSON.stringify(feature.geometry.coordinates);
  }

  function markerStyle(isVisited) {
    const color = isVisited ? 'green' : 'red';
    return { radius: 5, color, fillColor: color, fillOpacity: 0.8 };
  }

  function haversine([lat1, lon1], { lat: lat2, lng: lon2 }) {
    const R = 6371000;
    const toRad = deg => deg * Math.PI / 180;
    const dLat = toRad(lat2 - lat1), dLon = toRad(lon2 - lon1);
    const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon/2)**2;
    return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  }

  function loadVisited() {
    try {
      return new Set(JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'));
    } catch {
      return new Set();
    }
  }

  function saveVisited() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([...visited]));
  }
});
